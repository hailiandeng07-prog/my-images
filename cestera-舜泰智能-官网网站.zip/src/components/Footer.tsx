import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-black border-t border-white/5 py-12">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-start mb-12">
          <div className="mb-10 md:mb-0">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <span className="text-xl font-bold tracking-tighter text-white">CESTERA</span>
              <span className="h-4 w-px bg-white/20 mx-2"></span>
              <span className="text-xs font-medium tracking-widest uppercase text-gray-300">舜泰智能</span>
            </Link>
            <p className="text-[10px] text-gray-600 tracking-widest leading-relaxed">安全可靠、极致能效、更佳体验！<br/>专注智能叉车，提供具身智能物流机器人全线解决方案</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-12 md:gap-24">
            {[
              { title: "产品", links: [{ name: "智能叉车", path: "/forklift" }, { name: "平衡重叉车", path: "#" }, { name: "前移式叉车", path: "#" }] },
              { title: "场景", links: [{ name: "汽车制造", path: "#" }, { name: "冷链物流", path: "#" }, { name: "光伏组件", path: "#" }] },
              { title: "关于", links: [{ name: "舜泰简介", path: "#" }, { name: "核心技术", path: "#" }, { name: "荣誉奖项", path: "#" }] },
              { title: "其它", links: [{ name: "加入我们", path: "#" }, { name: "新闻动态", path: "#" }, { name: "法律条款", path: "#" }] }
            ].map((group, i) => (
              <div key={i} className="space-y-4">
                <h5 className="text-[10px] font-bold uppercase text-white tracking-widest">{group.title}</h5>
                <ul className="space-y-2 text-[10px] text-gray-500">
                  {group.links.map((link, j) => (
                    <li key={j}>
                      {link.path.startsWith('/') ? (
                        <Link to={link.path} className="hover:text-brand-green transition-colors">{link.name}</Link>
                      ) : (
                        <a href={link.path} className="hover:text-brand-green transition-colors">{link.name}</a>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center border-t border-white/5 pt-8 text-[9px] text-gray-700 font-mono tracking-tighter">
          <div className="mb-4 md:mb-0">
            © 2018-2026 浙江舜泰汽车有限公司. ALL RIGHTS RESERVED.
          </div>
          <div className="flex space-x-6">
            <span>浙ICP备xxxxxxx号</span>
            <span>浙公网安备 xxxxxxxxxxxxxxx号</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
