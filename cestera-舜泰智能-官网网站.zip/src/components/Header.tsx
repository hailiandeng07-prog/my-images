import { NavLink, Link } from "react-router-dom";
import { motion } from "motion/react";

export default function Header() {
  return (
    <header className="fixed top-0 w-full z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
      <nav className="container mx-auto px-6 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2 cursor-pointer">
          <span className="text-2xl font-bold tracking-tighter text-white">CESTERA</span>
          <span className="h-4 w-px bg-white/20 mx-2"></span>
          <span className="text-sm font-medium tracking-widest text-gray-300">舜泰智能</span>
        </Link>
        <div className="hidden md:flex items-center space-x-10 text-sm font-medium uppercase tracking-wider">
          <NavLink 
            to="/"
            className={({ isActive }) => 
              `${isActive ? 'text-brand-green' : 'text-gray-300 hover:text-brand-green'} transition-colors`
            }
          >
            首页
          </NavLink>
          <NavLink 
            to="/forklift"
            className={({ isActive }) => 
              `${isActive ? 'text-brand-green' : 'text-gray-300 hover:text-brand-green'} transition-colors`
            }
          >
            智能叉车
          </NavLink>
          <a href="#" className="text-gray-300 hover:text-brand-green transition-colors">应用场景</a>
          <a href="#" className="text-gray-300 hover:text-brand-green transition-colors">关于舜泰</a>
          <a href="#" className="text-gray-300 hover:text-brand-green transition-colors">加入舜泰</a>
          <a href="#" className="text-gray-300 hover:text-brand-green transition-colors">联系我们</a>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-xs text-gray-400">中文 | EN</span>
        </div>
      </nav>
    </header>
  );
}
