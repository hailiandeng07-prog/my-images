import { motion } from "motion/react";
import { Battery, Thermometer, Zap, Shield, CheckCircle2, ArrowRight, Play, TrendingUp, TrendingDown } from "lucide-react";

export default function ForkliftPage() {
  const advantages = [
    { icon: <Shield className="w-6 h-6" />, title: "安全防护", desc: "多重安全设计", sub: "防撞 / 急停 / 警示" },
    { icon: <Thermometer className="w-6 h-6" />, title: "宽温区作业", desc: "-25°C~+55°C", sub: "冷库稳定运行" },
    { icon: <Zap className="w-6 h-6" />, title: "自动充电", desc: "闲时自动回充", sub: "低电压20%触发" },
    { icon: <Battery className="w-6 h-6" />, title: "锂电池动力", desc: "80V/205-420Ah", sub: "续航持久" },
  ];

  const products = [
    {
      ton: "3.5T",
      model: "N35",
      title: "3.5T 智能平衡重",
      image: "https://github.com/hailiandeng07-prog/my-images/blob/main/35.png?raw=true",
      specs: [
        "额定载荷：3500kg",
        "起升高度：3000mm",
        "转弯半径：2380mm",
        "行驶速度：≤15km/h",
        "爬坡度：20%",
        "电池：80V/205Ah 锂电池",
        "电机：12KW/21KW"
      ],
      tag: "【专为重载工况打造 · 3.5吨大载荷 · 20%爬坡】"
    },
    {
      ton: "3.0T",
      model: "N30",
      title: "3.0T 智能平衡重",
      image: "https://github.com/hailiandeng07-prog/my-images/blob/main/30-2.png?raw=true",
      specs: [
        "额定载荷：3000kg",
        "起升高度：3000mm",
        "转弯半径：2380mm",
        "行驶速度：≤15km/h",
        "爬坡度：20%",
        "电池：80V/205Ah 锂电池",
        "电机：12KW/21KW"
      ],
      tag: "【通用物流场景 · 高效稳定 · 20%爬坡】"
    },
    {
      ton: "2.5T",
      model: "SQ25",
      title: "2.5T 智能平衡重",
      image: "https://github.com/hailiandeng07-prog/my-images/blob/main/25_20.png?raw=true",
      specs: [
        "额定载荷：2500kg",
        "起升高度：3000mm",
        "转弯半径：2350mm",
        "行驶速度：≤15km/h",
        "爬坡度：20%",
        "电池：80V/420Ah 锂电池",
        "电机：10KW/16.5KW"
      ],
      tag: "【2350mm极小转弯 · 窄通道穿梭 · 大容量电池】"
    },
    {
      ton: "2.0T",
      model: "SQ20",
      title: "2.0T 智能平衡重",
      image: "https://github.com/hailiandeng07-prog/my-images/blob/main/25_20.png?raw=true",
      specs: [
        "额定载荷：2000kg",
        "起升高度：3000mm",
        "转弯半径：2350mm",
        "行驶速度：≤15km/h",
        "爬坡度：15%",
        "电池：80V/420Ah 锂电池",
        "电机：10KW/16.5KW"
      ],
      tag: "【2310mm短车身 · 紧凑空间灵活机动 · 轻载首选】"
    }
  ];

  const functions = [
    { title: "实时路线规划", desc: "库区统筹" },
    { title: "智能交通调度", desc: "复杂路口管理" },
    { title: "远程监控控制", desc: "实时查看 / 接管" },
    { title: "低电量自动充电", desc: "自动回充" },
  ];

  const cases = [
    { title: "某砖厂无人化转运项目", details: ["效率提升70%", "人员减少90%", "日转运1060-1504万"] },
    { title: "某冷库智能仓仓储物流项目", details: ["-25°C冷库全天候作业", "数据可溯源管理", "降低货损率"] },
    { title: "某轮胎厂堆叠项目", details: ["解决4-10层堆叠难题", "效率提升50%", "消除安全隐患"] },
    { title: "某化工企业智能转运", details: ["自适应叉取多种料笼", "对接WMS柔性生产", "数字化管理"] },
  ];

  return (
    <div className="bg-brand-dark text-white">
      {/* Page Header / Hero */}
      <section className="relative pt-32 pb-24 bg-black overflow-hidden">
        <div className="absolute top-1/4 -right-20 w-96 h-96 bg-brand-green/10 rounded-full blur-[120px]"></div>
        <div className="container mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center space-x-4 mb-6">
              <div className="h-px w-12 bg-brand-green"></div>
              <span className="text-brand-green text-xs font-bold uppercase tracking-widest">Product Series</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter text-white uppercase">智能叉车系列</h1>
            <p className="text-gray-400 max-w-2xl leading-relaxed text-lg font-light border-l-4 border-brand-green pl-6">
              覆盖 2.0 吨至 3.5 吨载重需求，专为高强度工业环境打造，定义未来智慧物流新标准。
            </p>
          </motion.div>
        </div>
      </section>

      {/* Advantages - Using Glass Effect like Stats Bar */}
      <section className="py-24 bg-brand-dark">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between mb-16">
            <h2 className="text-3xl font-bold text-white uppercase tracking-tight">全系通用优势</h2>
            <div className="hidden md:block h-px flex-grow bg-white/5 mx-10"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {advantages.map((adv, i) => (
              <div key={i} className="glass-effect p-10 rounded-lg border-t-4 border-t-brand-green transition-all hover:translate-y-[-5px]">
                <div className="text-brand-green mb-6">{adv.icon}</div>
                <h3 className="text-lg font-bold mb-3 text-white uppercase tracking-wide">{adv.title}</h3>
                <div className="text-xl font-black text-white mb-1">{adv.desc}</div>
                <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">{adv.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Product List - Matching HomePage Product Cards */}
      <section className="py-24 bg-black">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-16 text-white uppercase tracking-tight">产品型号详解</h2>
          <div className="space-y-16">
            {products.map((product, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="group bg-brand-card border border-white/5 overflow-hidden flex flex-col md:flex-row hover:border-brand-green/30 transition-all"
              >
                <div className="md:w-2/5 bg-white flex items-center justify-center p-12 relative overflow-hidden">
                  <span className="text-[12rem] font-black text-black/5 absolute -bottom-10 -left-10 select-none leading-none">{product.ton}</span>
                  <div className="relative z-10 w-full aspect-square flex items-center justify-center group-hover:scale-110 transition-transform duration-700">
                    <img 
                      src={product.image} 
                      alt={product.title} 
                      className="max-h-full object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>
                <div className="md:w-3/5 p-12 flex flex-col justify-between">
                  <div>
                    <div className="text-brand-green text-[10px] font-bold uppercase tracking-[0.2em] mb-4">{product.model}</div>
                    <h3 className="text-3xl font-bold mb-8 text-white">{product.title}</h3>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-y-5 gap-x-12 text-sm text-gray-400">
                      {product.specs.map((spec, j) => (
                        <li key={j} className="flex items-center group/item">
                          <CheckCircle2 className="w-4 h-4 text-brand-green mr-3 flex-shrink-0 group-hover/item:scale-110 transition-transform" />
                          <span className="font-mono text-xs tracking-tighter">{spec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-12 pt-8 border-t border-white/5">
                    <div className="text-gray-500 text-[10px] font-bold py-3 px-6 rounded-sm inline-block mb-6 uppercase tracking-widest border border-white/10 bg-white/5">
                      {product.tag}
                    </div>
                    <div className="flex gap-4">
                      <button className="px-8 py-3 bg-white text-black font-bold text-[10px] uppercase tracking-widest hover:bg-brand-green transition-all">获取详细参数</button>
                      <button className="px-8 py-3 border border-white/10 text-white font-bold text-[10px] uppercase tracking-widest hover:border-brand-green transition-all">预约演示</button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Smart Functions */}
      <section className="py-24 bg-brand-dark">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white uppercase tracking-tight mb-4">智能平台核心功能</h2>
            <div className="w-20 h-1 bg-brand-green mx-auto"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {functions.map((func, i) => (
              <div key={i} className="p-10 bg-brand-card border border-white/5 hover:bg-zinc-800 transition-all cursor-default text-center group">
                <h3 className="text-lg font-bold mb-4 text-white group-hover:text-brand-green transition-colors">{func.title}</h3>
                <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">{func.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Success Cases */}
      <section className="py-24 bg-black">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-16 text-white uppercase tracking-tight">落地案例展示</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {cases.map((c, i) => (
              <div key={i} className="group p-10 bg-brand-card border border-white/5 hover:border-brand-green/50 transition-all">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="font-bold text-xl text-white">{c.title}</h3>
                  <ArrowRight className="w-5 h-5 text-brand-green opacity-0 group-hover:opacity-100 group-hover:translate-x-2 transition-all" />
                </div>
                <ul className="space-y-4">
                  {c.details.map((detail, j) => (
                    <li key={j} className="text-xs text-gray-400 flex items-center font-mono">
                      <span className="w-1.5 h-1.5 bg-brand-green rounded-full mr-4 animate-pulse-soft"></span>
                      {detail.includes("提升") ? (
                        <>
                          {detail.split("提升")[0]} <TrendingUp className="inline-block w-3 h-3 text-brand-green mx-1" /> {detail.split("提升")[1]}
                        </>
                      ) : detail.includes("减少") ? (
                        <>
                          {detail.split("减少")[0]} <TrendingDown className="inline-block w-3 h-3 text-red-500 mx-1" /> {detail.split("减少")[1]}
                        </>
                      ) : (
                        detail
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="glass-effect p-2 rounded-xl border border-white/10 overflow-hidden relative">
            <div className="aspect-video bg-zinc-900 flex items-center justify-center group cursor-pointer relative overflow-hidden">
              <div className="z-10 text-center">
                <div className="w-20 h-20 rounded-full border border-brand-green flex items-center justify-center mb-4 mx-auto group-hover:bg-brand-green transition-colors">
                  <Play className="w-8 h-8 text-white fill-white ml-1" />
                </div>
                <p className="text-[10px] uppercase tracking-widest font-bold text-white">观看实拍作业视频</p>
              </div>
              <div className="absolute inset-0 p-8 flex flex-col justify-between opacity-30 pointer-events-none font-mono text-[10px]">
                <div className="flex justify-between uppercase">
                  <span>CASE_STUDY // COLD_STORAGE_01</span>
                  <span className="text-brand-green">Active Monitoring</span>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="border border-white/20 p-2">Temp: -25.4°C</div>
                  <div className="border border-white/20 p-2">Efficiency: +70%</div>
                  <div className="border border-white/20 p-2">Status: OPTIMAL</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Commitment */}
      <section className="py-32 bg-brand-dark relative overflow-hidden">
        <div className="absolute bottom-0 left-0 w-full h-1 bg-brand-green"></div>
        <div className="container mx-auto px-6 text-center relative z-10">
          <h2 className="text-5xl font-black mb-16 text-white tracking-tighter uppercase">售后服务承诺</h2>
          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8 text-left mb-20">
            {[
              { title: "质保体系", content: "整车质保 1 年，锂电池质保 5 年或 10000 小时，核心部件终身技术支持。" },
              { title: "响应速度", content: "7×24 小时技术支持，2 小时内快速响应，48 小时内工程师到场解决。" },
              { title: "智能巡检", content: "每季度定期线下巡检，结合物联网云平台远程监控，实现故障主动预警。" },
              { title: "专业培训", content: "提供免费的操作员培训、安全作业培训及完整的数字化技术文档支持。" }
            ].map((item, i) => (
              <div key={i} className="p-8 bg-brand-card border border-white/5 border-l-4 border-l-brand-green">
                <h4 className="text-white font-bold mb-3 uppercase tracking-widest text-sm">{item.title}</h4>
                <p className="text-gray-500 text-sm leading-relaxed">{item.content}</p>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap justify-center gap-6">
          </div>
        </div>
      </section>
    </div>
  );
}
