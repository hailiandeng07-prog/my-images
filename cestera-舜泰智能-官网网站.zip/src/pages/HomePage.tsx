import { motion } from "motion/react";
import { Play, ArrowRight, Phone, Mail, MapPin, TrendingUp, Battery, Thermometer, Zap, Shield } from "lucide-react";
import { Link } from "react-router-dom";

export default function HomePage() {
  return (
    <div className="bg-brand-dark">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div className="absolute top-1/4 -right-20 w-96 h-96 bg-brand-green/10 rounded-full blur-[120px]"></div>
        <div className="container mx-auto px-6 grid md:grid-cols-2 gap-12 items-center z-10">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-6xl md:text-8xl font-black mb-4 tracking-tighter text-white">CESTERA</h1>
            <h2 className="text-3xl font-bold mb-8 text-gray-400">舜泰智能</h2>
            <p className="text-xl md:text-2xl font-light mb-4 border-l-4 border-brand-green pl-6">安全可靠、极致能效、更佳体验！</p>
            <p className="text-gray-500 max-w-lg mb-12">专注智能叉车，提供具身智能物流机器人全线解决方案</p>
            <div className="flex flex-wrap gap-4">
            </div>
            <div className="mt-16 flex space-x-8">
              <div className="flex flex-col">
                <span className="text-brand-green text-xs mb-1">智能AI</span>
                <div className="h-1 w-12 bg-brand-green"></div>
              </div>
              <div className="flex flex-col">
                <span className="text-gray-500 text-xs mb-1">锂电池</span>
                <div className="h-1 w-12 bg-gray-800"></div>
              </div>
              <div className="flex flex-col">
                <span className="text-gray-500 text-xs mb-1">物联网</span>
                <div className="h-1 w-12 bg-gray-800"></div>
              </div>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="relative"
          >
            <img 
              src="https://github.com/hailiandeng07-prog/my-images/blob/main/%E9%A6%96%E9%A1%B535.png?raw=true" 
              alt="CESTERA Smart Forklift" 
              className="w-full h-auto drop-shadow-[0_35px_35px_rgba(0,255,0,0.15)]"
              referrerPolicy="no-referrer"
            />
          </motion.div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="py-12 bg-black border-y border-white/5">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 gap-8">
            {[
              { label: "设备在线率", value: "98.5%", color: "text-brand-green" },
              { label: "全天候运行", value: "24/7", color: "text-white" },
            ].map((stat, i) => (
              <div key={i} className="glass-effect p-6 rounded-lg">
                <div className={`text-4xl font-bold mb-1 ${stat.color}`}>
                  {stat.value.split('+').map((part, index, array) => (
                    <span key={index}>
                      {part}
                      {index < array.length - 1 && <sup className="text-sm opacity-40 ml-0.5 font-light">+</sup>}
                    </span>
                  ))}
                </div>
                <div className="text-xs uppercase tracking-widest text-gray-500">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Product Series */}
      <section className="py-24 bg-brand-dark">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-start md:items-end justify-between mb-16 gap-4">
            <div>
              <h2 className="text-4xl font-bold text-white mb-4">智能叉车产品系列</h2>
              <div className="w-24 h-1 bg-brand-green"></div>
            </div>
            <p className="text-gray-500 text-sm max-w-md md:text-right">专为高强度仓储及制造环境设计，结合最先进的自主导航技术与卓越的机械性能。</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Product Card 1: 3.5T */}
            <motion.div 
              whileHover={{ y: -10 }}
              className="group bg-brand-card border border-white/5 overflow-hidden hover:border-brand-green/50 transition-all"
            >
              <div className="aspect-square bg-white overflow-hidden flex items-center justify-center p-6">
                <img 
                  src="https://github.com/hailiandeng07-prog/my-images/blob/main/35.png?raw=true" 
                  alt="CPD35-AZ" 
                  className="max-h-full object-contain group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="text-[10px] text-brand-green font-bold mb-2 uppercase tracking-widest">Model: N35</div>
                <h3 className="text-xl font-bold text-white mb-4">3.5T 智能平衡重</h3>
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between text-[10px] text-gray-500"><span>额定载重</span><span className="text-white">3500kg</span></div>
                  <div className="flex justify-between text-[10px] text-gray-500"><span>举升高度</span><span className="text-white">3000mm</span></div>
                </div>
                <Link to="/forklift" className="block w-full py-3 border border-white/10 hover:bg-white hover:text-black transition-all text-[10px] font-bold uppercase tracking-widest text-center">查看详情</Link>
              </div>
            </motion.div>
            {/* Product Card 2: 3.0T */}
            <motion.div 
              whileHover={{ y: -10 }}
              className="group bg-brand-card border border-white/5 overflow-hidden hover:border-brand-green/50 transition-all"
            >
              <div className="aspect-square bg-white overflow-hidden flex items-center justify-center p-6">
                <img 
                  src="https://github.com/hailiandeng07-prog/my-images/blob/main/30-2.png?raw=true" 
                  alt="CPD30-AZ" 
                  className="max-h-full object-contain group-hover:scale-110 transition-transform duration-500 opacity-90"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="text-[10px] text-brand-green font-bold mb-2 uppercase tracking-widest">Model: N30</div>
                <h3 className="text-xl font-bold text-white mb-4">3.0T 智能平衡重</h3>
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between text-[10px] text-gray-500"><span>额定载重</span><span className="text-white">3000kg</span></div>
                  <div className="flex justify-between text-[10px] text-gray-500"><span>举升高度</span><span className="text-white">3000mm</span></div>
                </div>
                <Link to="/forklift" className="block w-full py-3 border border-white/10 hover:bg-white hover:text-black transition-all text-[10px] font-bold uppercase tracking-widest text-center">查看详情</Link>
              </div>
            </motion.div>
            {/* Product Card 3: 2.5T */}
            <motion.div 
              whileHover={{ y: -10 }}
              className="group bg-brand-card border border-white/5 overflow-hidden hover:border-brand-green/50 transition-all"
            >
              <div className="aspect-square bg-white overflow-hidden flex items-center justify-center p-6">
                <img 
                  src="https://github.com/hailiandeng07-prog/my-images/blob/main/25_20.png?raw=true" 
                  alt="CPD25-AZ" 
                  className="max-h-full object-contain group-hover:scale-110 transition-transform duration-500 opacity-90"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="text-[10px] text-brand-green font-bold mb-2 uppercase tracking-widest">Model: SQ25</div>
                <h3 className="text-xl font-bold text-white mb-4">2.5T 智能平衡重</h3>
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between text-[10px] text-gray-500"><span>额定载重</span><span className="text-white">2500kg</span></div>
                  <div className="flex justify-between text-[10px] text-gray-500"><span>举升高度</span><span className="text-white">3000mm</span></div>
                </div>
                <Link to="/forklift" className="block w-full py-3 border border-white/10 hover:bg-white hover:text-black transition-all text-[10px] font-bold uppercase tracking-widest text-center">查看详情</Link>
              </div>
            </motion.div>
            {/* Product Card 4: 2.0T */}
            <motion.div 
              whileHover={{ y: -10 }}
              className="group bg-brand-card border border-white/5 overflow-hidden hover:border-brand-green/50 transition-all"
            >
              <div className="aspect-square bg-white overflow-hidden flex items-center justify-center p-6">
                <img 
                  src="https://github.com/hailiandeng07-prog/my-images/blob/main/25_20.png?raw=true" 
                  alt="CPD20-AZ" 
                  className="max-h-full object-contain group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="text-[10px] text-brand-green font-bold mb-2 uppercase tracking-widest">Model: SQ20</div>
                <h3 className="text-xl font-bold text-white mb-4">2.0T 智能平衡重</h3>
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between text-[10px] text-gray-500"><span>额定载重</span><span className="text-white">2000kg</span></div>
                  <div className="flex justify-between text-[10px] text-gray-500"><span>举升高度</span><span className="text-white">3000mm</span></div>
                </div>
                <Link to="/forklift" className="block w-full py-3 border border-white/10 hover:bg-white hover:text-black transition-all text-[10px] font-bold uppercase tracking-widest text-center">查看详情</Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Core Advantages Section */}
      <section className="py-24 bg-black/50 relative">
        <div className="container mx-auto px-6">
          <div className="mb-20">
            <h2 className="text-4xl font-black text-white tracking-tighter uppercase">产品核心特点</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: <Shield className="w-8 h-8 text-brand-green" />, title: "安全防护", desc: "多重安全设计", sub: "防撞 / 急停 / 警示" },
              { icon: <Thermometer className="w-8 h-8 text-brand-green" />, title: "宽温区作业", desc: "-25°C~+55°C", sub: "冷库稳定运行" },
              { icon: <Zap className="w-8 h-8 text-brand-green" />, title: "自动充电", desc: "闲时自动回充", sub: "低电压20%触发" },
              { icon: <Battery className="w-8 h-8 text-brand-green" />, title: "锂电池动力", desc: "80V/205-420Ah", sub: "续航持久" },
            ].map((adv, i) => (
              <div key={i} className="p-10 bg-brand-card border border-white/5 hover:border-brand-green/30 transition-all group relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-0 bg-brand-green group-hover:h-full transition-all duration-500"></div>
                <div className="mb-8 group-hover:scale-110 transition-transform duration-300">{adv.icon}</div>
                <h3 className="text-xl font-bold text-white mb-3">{adv.title}</h3>
                <p className="text-brand-green text-sm font-bold mb-1">{adv.desc}</p>
                <p className="text-gray-500 text-[10px] uppercase tracking-widest">{adv.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reliability Section */}
      <section className="py-24 bg-black relative">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-white mb-4">极端环境 · 稳定可靠</h2>
          <p className="text-gray-500 mb-16 max-w-2xl">舜泰智能叉车经过严苛的工业级测试，确保在各种极端气候与复杂工况下依然保持卓越性能与高度稳定性。</p>
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="bg-brand-card p-10 border-t-4 border-brand-green relative overflow-hidden group min-h-[300px] flex flex-col justify-center">
              <video 
                src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" 
                className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:opacity-60 transition-opacity pointer-events-none"
                autoPlay
                muted
                loop
                playsInline
              />
              <div className="relative z-10">
                <div className="text-xs uppercase text-gray-500 mb-4 tracking-tighter">高温环境测试</div>
                <div className="text-5xl font-black text-white mb-6">+55°C</div>
                <p className="text-sm text-gray-400 leading-relaxed">核心三电系统（电池、电机、电控）在高温密闭环境下持续运行 72 小时，散热效率 <TrendingUp className="inline-block w-4 h-4 text-brand-green mb-1" /> 30%，系统零报警。</p>
              </div>
            </div>
            <div className="bg-brand-card p-10 border-t-4 border-blue-500">
              <div className="text-xs uppercase text-gray-500 mb-4 tracking-tighter">低温环境测试</div>
              <div className="text-5xl font-black text-white mb-6">-25°C</div>
              <p className="text-sm text-gray-400 leading-relaxed">极寒冷库模拟测试，液压系统响应时间小于 1.5s，电池具备主动加热功能，确保极寒环境下稳定续航。</p>
            </div>
            <div className="bg-brand-card p-10 border-t-4 border-gray-500">
              <div className="text-xs uppercase text-gray-500 mb-4 tracking-tighter">雨雪与潮湿测试</div>
              <div className="text-5xl font-black text-white mb-6">IP67</div>
              <p className="text-sm text-gray-400 leading-relaxed">整车关键零部件防护等级达 IP67，通过强力高压淋雨测试及高压水枪冲洗测试，电气绝缘稳定无涉水短路风险。</p>
            </div>
          </div>
          <div className="glass-effect p-2 rounded-xl border border-white/10 overflow-hidden relative">
            <div className="aspect-video bg-zinc-900 flex items-center justify-center group relative overflow-hidden">
              <video 
                src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" 
                controls
                className="w-full h-full object-cover"
                poster="https://picsum.photos/seed/forklift-test/1280/720"
              />
              <div className="absolute top-4 left-4 p-4 flex flex-col justify-between opacity-40 pointer-events-none z-10">
                <div className="flex justify-between text-[10px] font-mono uppercase space-x-4">
                  <span>LIVE // TEST_CELL_04</span>
                  <span className="text-brand-green">System Stable</span>
                </div>
              </div>
            </div>
          </div>
          <p className="mt-8 text-center text-[10px] text-gray-600 uppercase tracking-widest">所有测试数据来自浙江舜泰汽车有限公司测试中心</p>
        </div>
      </section>

      {/* Scene Section */}
      <section className="py-24 bg-brand-dark">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-white mb-4 text-center">服务多行业，赋能全场景</h2>
          <p className="text-gray-500 mb-12 text-center max-w-2xl mx-auto">舜泰智能致力于为全球客户提供高效、可靠的智慧物流解决方案。已成功应用于多个行业头部生产现场。</p>
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            {["全部", "汽车", "光伏", "3C", "仓储", "冷链", "重工"].map((tab, i) => (
              <button key={i} className={`px-6 py-2 rounded-full border text-sm font-bold transition-all ${i === 0 ? 'border-brand-green text-brand-green' : 'border-white/10 hover:border-white/40 text-gray-400'}`}>
                {tab}
              </button>
            ))}
          </div>
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 group">
              <div className="relative h-[500px] bg-zinc-800 rounded-lg overflow-hidden">
                <img 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuAsja2DjHn0mb7N9V2M_ArBiNBADZTF3_sZMd2DzZN7LPtwVLDE1QmL8MG5jDClnX9_Dg3oKEL_DrUdjIezwtGPNMrW6zhQOLcNzGh3GqeUpPGDmqI-GrhpOD702SjkbzNQgHWgHCUn9IvdERN0R9vQyCdSDcnUHEbCyvqE2UyJUpn9VozIJgV30PVe68OjSRkx96Aycmey0kj2fQ91G3Sswa7Rfrttrt8MhloK3jNcACK7qSz156uvsS3Dtf9OYLRhBDAcOrlv_puM" 
                  alt="Automotive Case" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60"></div>
                <div className="absolute top-6 left-6 bg-brand-green text-black text-[10px] font-bold px-3 py-1 rounded-sm uppercase tracking-widest">Featured Case // 汽车行业</div>
                <div className="absolute bottom-8 left-8 right-8">
                  <h3 className="text-3xl font-bold text-white mb-4">浙江舜泰 · 某头部车企总装车间</h3>
                  <div className="flex space-x-12">
                    <div>
                      <div className="text-2xl font-black text-brand-green">35%</div>
                      <div className="text-[10px] uppercase text-gray-400">效率提升</div>
                    </div>
                    <div>
                      <div className="text-2xl font-black text-white">20+</div>
                      <div className="text-[10px] uppercase text-gray-400">无人叉车投入</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-4">
              {[
                { industry: "重工制造", title: "某砖厂无人化转运项目", stats: "效率提升70% · 人员减少90%", img: "https://picsum.photos/seed/brick/400/300" },
                { industry: "汽车配套", title: "某轮胎厂堆叠项目", stats: "效率提升50% · 解决4-10层堆叠", img: "https://picsum.photos/seed/tire/400/300" },
                { industry: "光伏行业", title: "江苏某光伏组件智能化工厂", stats: "58% 人力降低", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuAQLcUxccy2dQFZ1P7e_qCXY_pxqnFCextouSK66HTt3FlDpA5cAnZwQYR7DXAGGFZT3Qlp-9ERpsjFloMCUqYEasp8wy3TEhXxN6eZ87ZBx0yZEfc36rlwckqV76k2uKNb8vWEjjyW7p9-ZqmTthbbaAixYFQK6F31Aw0asXswwhDEKipRN3mqK5mQX839sHBpa7EcuFE6GR94aMRSzgur9rjgcXleQzZOieQSHNKa4i-GVaa-HJy4pcGq-mWLGJ9YIfWW1Gj7rlL_" },
              ].map((item, i) => (
                <div key={i} className="bg-brand-card p-4 border border-white/5 flex items-center space-x-4 hover:border-brand-green/30 transition-all cursor-pointer group">
                  <div className="w-20 h-20 flex-shrink-0 bg-zinc-800 overflow-hidden">
                    <img src={item.img} alt={item.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all" referrerPolicy="no-referrer" />
                  </div>
                  <div>
                    <div className="text-[9px] text-brand-green uppercase mb-1">{item.industry}</div>
                    <h4 className="text-sm font-bold text-white mb-1 line-clamp-1">{item.title}</h4>
                    <p className="text-[10px] text-gray-500">{item.stats}</p>
                  </div>
                </div>
              ))}
              <button className="mt-auto w-full py-4 border border-white/10 text-[10px] font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all">查看更多案例</button>
            </div>
          </div>
          <div className="mt-16 text-center">
            <button className="px-12 py-4 bg-transparent border border-white/20 hover:border-brand-green text-xs font-bold uppercase tracking-widest">探索更多行业案例</button>
          </div>
        </div>
      </section>

      {/* About/Partner Section */}
      <section className="py-24 bg-black overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-brand-green/20 to-transparent"></div>
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <div>
              <div className="text-[10px] text-brand-green font-bold uppercase tracking-[0.4em] mb-4">About Cestera // 舜泰智能</div>
              <h2 className="text-5xl font-black text-white mb-8 tracking-tighter uppercase">值得信赖的<br />合作伙伴</h2>
              <div className="space-y-6 text-gray-400 leading-relaxed font-light">
                <p>舜泰智能（Cestera）作为全球领先的智能物流机器人专家，致力于定义具备AI进化能力的工业级机器人系统。我们不仅提供硬核硬件设备，更深耕于全栈式智慧物流解决方案，助力企业实现从传统人工搬运向数字化、智能化转型的跨越。</p>
                <p>凭借在工业视觉、高精度SLAM导航以及群体智能调度等领域的核心技术积累，我们的方案已广泛应用于重型制造、电子半导体、汽车配套及服装物流等多个行业。我们坚持以安全可靠、极致能效、更佳体验为核心，持续通过技术迭代，为全球合作伙伴创造可持续的竞争优势。</p>
              </div>
              <div className="mt-10 flex flex-wrap gap-3">
                {["实时路线规划", "智能交通调度", "远程监控控制", "低电量自动充电"].map((tech, i) => (
                  <span key={i} className="px-4 py-2 bg-zinc-900 border border-white/5 text-[10px] text-gray-400 uppercase tracking-widest hover:border-brand-green/30 transition-colors cursor-default">{tech}</span>
                ))}
              </div>
              <button className="mt-12 group flex items-center space-x-6">
                <span className="w-14 h-14 rounded-full border border-brand-green flex items-center justify-center text-brand-green group-hover:bg-brand-green group-hover:text-black transition-all">
                  <ArrowRight className="w-6 h-6" />
                </span>
                <span className="text-xs font-bold uppercase tracking-widest text-white">了解更多关于我们的故事</span>
              </button>
            </div>
            <div className="relative">
              <div className="absolute -inset-10 bg-brand-green/5 blur-[100px] rounded-full"></div>
              <div className="grid grid-cols-2 gap-4 relative z-10">
                {[
                  { label: "成立年份", value: "2018", sub: "Established" },
                  { label: "资质荣誉", value: "50+", sub: "Honors" },
                  { label: "核心专利", value: "120+", sub: "Patents" },
                  { label: "服务客户", value: "300+", sub: "Clients" }
                ].map((stat, i) => (
                  <div key={i} className="bg-brand-card p-10 border border-white/5 hover:border-brand-green/20 transition-all group">
                    <div className="text-4xl font-black text-white mb-1 group-hover:text-brand-green transition-colors">{stat.value}</div>
                    <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold mb-4">{stat.label}</div>
                    <div className="w-8 h-0.5 bg-zinc-800 group-hover:w-full transition-all duration-500"></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Careers Section */}
      <section className="py-24 bg-brand-dark">
        <div className="container mx-auto px-6">
          <div className="bg-brand-card p-12 md:p-20 relative overflow-hidden border border-white/5">
            <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-brand-green/5 to-transparent"></div>
            <div className="grid md:grid-cols-2 gap-16 relative z-10">
              <div>
                <div className="text-[10px] text-brand-green font-bold uppercase tracking-[0.4em] mb-4">Join Our Mission // 加入我们</div>
                <h2 className="text-5xl font-black text-white mb-8 tracking-tighter uppercase">智造未来<br />定义新边界</h2>
                <p className="text-gray-400 italic mb-10 text-lg font-light leading-relaxed">“我们致力于定义人类智能的物理融入。在这里，每一个创新想法都被尊重，每一秒才华得以闪耀，让我们共同定义智慧搬运的新边界。”</p>
                <div className="flex flex-wrap gap-3 mb-12">
                  {["算法研发", "嵌入式开发", "机械设计", "全球营销"].map((tag, i) => (
                    <span key={i} className="px-4 py-2 bg-zinc-900 text-[10px] text-gray-500 uppercase tracking-widest border border-white/5">{tag}</span>
                  ))}
                </div>
                <button className="px-10 py-4 bg-brand-green text-black font-bold uppercase tracking-widest text-xs hover:brightness-110 transition-all">查看开放职位</button>
              </div>
              <div className="flex flex-col justify-center space-y-8 border-l border-white/10 pl-12">
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">研发类岗位</h4>
                  <p className="text-sm text-gray-500">聚焦算法、软件与硬件协同，参与下一代柔性智能物流机器人核心研发。</p>
                </div>
                <div className="space-y-4">
                  {[
                    "参与智能视觉/导航系统的核心模块设计",
                    "负责多机协同、AI感知方案开发",
                    "开展高可靠、高防护硬件工程体系方案"
                  ].map((item, i) => (
                    <div key={i} className="flex items-center text-xs text-gray-400">
                      <div className="w-1.5 h-1.5 bg-brand-green rounded-full mr-4"></div>
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Commitment Section */}
      <section className="py-24 bg-black border-y border-white/5">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between mb-16 gap-8">
            <h2 className="text-4xl font-bold text-white tracking-tight">全生命周期 · 服务承诺</h2>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { title: "质保体系", content: "整车质保 1 年，锂电池质保 5 年，核心部件终身支持。" },
              { title: "响应速度", content: "2 小时内快速响应，专业团队在线诊断与远程协助。" },
              { title: "智能巡检", content: "每季度定期线下巡检，云平台实时监控故障预警。" },
              { title: "专业培训", content: "免费操作培训、安全作业培训及完整技术文档支持。" }
            ].map((item, i) => (
              <div key={i} className="p-8 bg-brand-card border-t-2 border-brand-green hover:bg-zinc-800 transition-all">
                <h4 className="text-white font-bold mb-4 text-sm uppercase tracking-widest">{item.title}</h4>
                <p className="text-gray-500 text-xs leading-relaxed">{item.content}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 bg-black">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-3 gap-16">
            <div className="lg:col-span-1">
              <h2 className="text-4xl font-bold text-white mb-4">立即咨询 · 获取定制方案</h2>
              <p className="text-brand-green text-sm font-bold mb-12">7×24小时响应 · 免费现场调研</p>
              <div className="space-y-10">
                <div>
                  <div className="text-[10px] uppercase text-gray-500 mb-2">服务热线</div>
                  <div className="text-2xl font-bold text-white flex items-center">
                    <Phone className="w-5 h-5 mr-3 text-brand-green" />
                    400-XXX-XXXX
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase text-gray-500 mb-2">商务邮箱</div>
                  <div className="text-2xl font-bold text-white flex items-center">
                    <Mail className="w-5 h-5 mr-3 text-brand-green" />
                    contact@cestera.com
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase text-gray-500 mb-2">公司地址</div>
                  <div className="text-sm text-gray-400 leading-relaxed flex items-start">
                    <MapPin className="w-5 h-5 mr-3 text-brand-green mt-1 flex-shrink-0" />
                    浙江省湖州市德清县武源街道XXX路XX号
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-2">
              <form className="grid grid-cols-1 md:grid-cols-2 gap-6 p-10 bg-brand-card rounded-lg border border-white/5">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase text-gray-500 font-bold">姓名</label>
                  <input className="w-full bg-zinc-900 border-white/10 text-white focus:border-brand-green focus:ring-0 px-4 py-3 rounded-sm transition-all" type="text" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase text-gray-500 font-bold">公司名称</label>
                  <input className="w-full bg-zinc-900 border-white/10 text-white focus:border-brand-green focus:ring-0 px-4 py-3 rounded-sm transition-all" type="text" />
                </div>
                <div className="md:col-span-2 space-y-1">
                  <label className="text-[10px] uppercase text-gray-500 font-bold">联系电话</label>
                  <input className="w-full bg-zinc-900 border-white/10 text-white focus:border-brand-green focus:ring-0 px-4 py-3 rounded-sm transition-all" type="tel" />
                </div>
                <div className="md:col-span-2 space-y-1">
                  <label className="text-[10px] uppercase text-gray-500 font-bold">需求描述</label>
                  <textarea className="w-full bg-zinc-900 border-white/10 text-white focus:border-brand-green focus:ring-0 px-4 py-3 rounded-sm transition-all" rows={4}></textarea>
                </div>
                <div className="md:col-span-2">
                  <button className="w-full py-4 bg-brand-green text-black font-black uppercase tracking-widest text-sm hover:brightness-110 transition-all" type="submit">提交咨询</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
